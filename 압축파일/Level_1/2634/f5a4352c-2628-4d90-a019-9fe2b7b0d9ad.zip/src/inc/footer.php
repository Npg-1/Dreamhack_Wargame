<div class="foot"><div>© MY Blog</div></div>
</div>
</body>
</html>
