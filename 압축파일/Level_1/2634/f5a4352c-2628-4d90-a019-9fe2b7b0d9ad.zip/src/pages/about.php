<section class="hero">
  <h1>About</h1>
  <p>블로그 개설일 2025/12/30</p>
</section>

<div class="grid">
  <div class="card">
    <span class="pill hot">MY Blog</span>
    <div class="hr"></div>
    <div style="color:rgba(255,255,255,.70);font-size:13px;line-height:1.7">
      숏코드 <code style="font-family:ui-monospace;color:rgba(255,255,255,.88)">{{include: ...}}</code>
      를 사용해 본문에 내용을 추가하세요.
    </div>
  </div>
  <div class="card">
    <span class="pill">Report</span>
    <div class="hr"></div>
    <div style="color:rgba(255,255,255,.62);font-size:13px">
      <!-- TODO -->
    </div>
  </div>
</div>
