<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Main Page</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
<div class="container">
    <h1>Welcome</h1>
    <ul>
        <li><a href="login.php">Login</a></li>
        <li><a href="edit_profile.php">Edit Profile</a></li>
    </ul>
</div>
</body>
</html>
